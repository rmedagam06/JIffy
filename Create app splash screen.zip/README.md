
  # Create app splash screen

  This is a code bundle for Create app splash screen. The original project is available at https://www.figma.com/design/waLnxJmKUrT51epNVmELLe/Create-app-splash-screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  