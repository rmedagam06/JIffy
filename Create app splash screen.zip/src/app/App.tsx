import giraffeRaw from "@/imports/Jiffy_Animal__Logo_without_name_-Photoroom.png";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";


export default function App() {
  return (
    <div
      className="size-full flex flex-col items-center justify-center relative overflow-hidden"
      style={{ backgroundColor: "#F5E6C8", fontFamily: "'Fredoka', sans-serif" }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 45%, rgba(255,255,255,0.18) 0%, transparent 70%)",
        }}
      />

      <div className="mascot-bounce flex-1 flex items-center justify-center">
        <ImageWithFallback src={giraffeRaw} alt="Jiffy the giraffe" className="w-64 h-64 object-contain drop-shadow-xl" />
      </div>

      <div className="brand-fadein pb-20 flex flex-col items-center gap-1">
        <span
          className="text-6xl font-bold tracking-wide select-none"
          style={{ color: "#5C3010", letterSpacing: "0.02em", textShadow: "0 2px 0 rgba(0,0,0,0.08)" }}
        >
          Jiffy
        </span>
        <span
          className="text-base font-semibold tracking-widest uppercase select-none"
          style={{ color: "rgba(92,48,16,0.55)", letterSpacing: "0.18em" }}
        >
          Learn anything. One scroll at a time.
        </span>
      </div>

      <style>{`
        @keyframes mascotBounce {
          0%   { opacity: 0; transform: scale(0.4); }
          55%  { opacity: 1; transform: scale(1.1); }
          70%  { transform: scale(0.96); }
          82%  { transform: scale(1.04); }
          100% { transform: scale(1); }
        }
        @keyframes brandFadeIn {
          0%   { opacity: 0; transform: translateY(24px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .mascot-bounce {
          animation: mascotBounce 0.9s cubic-bezier(0.22, 1, 0.36, 1) 0.15s both;
        }
        .brand-fadein {
          animation: brandFadeIn 0.55s ease-out 0.85s both;
        }
      `}</style>
    </div>
  );
}
